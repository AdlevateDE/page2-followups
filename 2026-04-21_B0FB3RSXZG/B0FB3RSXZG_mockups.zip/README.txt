VORSCHLAGSBILDER FUER EURE MAGNESIUMCITRAT-LISTING (ASIN B0FB3RSXZG)
================================================================

Dieses ZIP enthaelt 6 Amazon-konforme Bildvorschlaege, die auf der
Competitor-Analyse basieren. Alle Bilder wurden mit KI-Bildgeneration
erstellt (fal-ai/nano-banana-2) und folgen den Amazon Style Guidelines
(keine Markennamen der Wettbewerber, keine Superlative, keine Disease-Claims).

---

MAIN-IMAGE-VARIANTEN (Slot 1 -- Produkt-Hauptbild, 3 Varianten zum Testen)

main_v1_jahresvorrat.jpg
  Gelber Kraftpapier-Tag "1000 Kapseln / Jahresvorrat" am Beutelhals,
  4-6 Kapseln unten rechts. Adaptiert das Pattern von Sunday Natural und
  Natural Elements. Optimal fuer Suche nach Jahresvorrat-Keywords.

main_v2_hochdosiert.jpg
  Gelber Tag "300 mg elementar pro Tag". Schliesst die Dosis-Luecke
  gegen ProFuel (400mg) und Feel Natural. Optimal fuer Zielgruppe,
  die explizit nach Dosierung sucht.

main_v3_made_in_germany.jpg
  Rundes Qualitaetssiegel "Entwickelt in Deutschland" mit DE-Flagge
  am Beutelhals (Pattern von Feel Natural). Kompensiert die aktuell
  niedrige Review-Anzahl durch Herkunfts-Trust.

---

SECONDARY-IMAGE-MOCKUPS (Slot 2-4 -- Bildergalerie)

mockup_slot2_jahresvorrat.jpg
  Jahresvorrat-Kalender-Grid: "1000 Kapseln = 333 Tage Versorgung".
  Macht die Packungsgroesse in 2 Sekunden begreiflich.

mockup_slot3_pro_kapsel_vergleich.jpg
  Pro-Kapsel-Wert-Vergleich mit anonymen Container-Silhouetten
  (200 / 365 / 1000 Kapseln). Ankert den 0,06 EUR/Kapsel-USP.

mockup_slot4_300mg_wirkung.jpg
  EFSA-konformes Wirkungs-Wheel mit 8 Icons um grosse Kapsel mit
  300mg-Banderole (Muskelfunktion, Nervensystem, Energiestoffwechsel,
  Knochen, Zaehne, Muedigkeit-Reduktion, Elektrolyt-Balance,
  Eiweisssynthese).

---

UPLOAD-ANLEITUNG (Amazon Seller Central)

1. Seller Central -> Inventar -> Produkt bearbeiten -> Bilder
2. Fuer Main-Image: NUR eine der drei Varianten testen. Empfehlung
   v1 (Jahresvorrat), weil der staerkste USP bei euch.
3. Secondary-Images als Slot 2, 3, 4 hochladen (oder beliebige Slots
   frei lassen). Reihenfolge ist flexibel.
4. Nach Upload 3-7 Tage warten bevor Performance gemessen wird
   (Amazon braucht Zeit um die neuen Bilder zu indexieren).

WICHTIG: Diese Bilder sind Vorschlaege basierend auf Competitor-Analyse
und in der Amazon-Grauzone. Sunday Natural + Natural Elements + Feel
Natural nutzen sehr aehnliche Patterns auf Page 1 ohne Probleme, aber
offizielle Amazon-Regel sagt "kein Text im Main-Image". Im Zweifelsfall
erst nur die Secondary-Images (Slot 2-4) hochladen, die sind sicher.

---

FRAGEN?

benjamin@adlevate.de
https://calendly.com/kundenservice-adlevate/101
